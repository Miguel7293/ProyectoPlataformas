<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
</script>

<template>
<h1>"Hello World"</h1>
</template>


